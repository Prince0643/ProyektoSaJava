
public class arithmeticOperatorsPCT {

    public static void main(String[] args) {

        // declared 2 integers
        int x = 10, y = 7;
        
        // this will be the operations that will be initialized later
        int sum, sub, multi, div;
        sum = x + y;
        sub = x - y;
        multi = x * y;
        div = x / y;

        System.out.println("Addition: " + sum);
        System.out.println("Subtraction: " + sub);
        System.out.println("Multiplication: " + multi);
        System.out.println("Division: " + div);
    }
}
